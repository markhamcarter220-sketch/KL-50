import { render } from '@testing-library/react';
import App from '../../frontend/src/App.jsx';

test('app renders', () => {
  render(<App />);
});
