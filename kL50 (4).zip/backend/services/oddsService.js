// oddsService.js - KL29
async function fetchOdds() {
  return { ok: true, data: [] };
}
module.exports = { fetchOdds };
