// normalizeOdds.js - KL29
function normalizeOdds(raw) {
  return raw;
}
module.exports = { normalizeOdds };
