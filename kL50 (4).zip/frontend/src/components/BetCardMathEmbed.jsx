
import ScanMathIntegration from './ScanMathIntegration';
export default function BetCardMathEmbed({ bet }) {
  return <ScanMathIntegration bet={bet} />;
}
