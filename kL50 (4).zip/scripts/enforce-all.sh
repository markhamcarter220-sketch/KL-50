#!/bin/bash
node scripts/enforce-structure.js
